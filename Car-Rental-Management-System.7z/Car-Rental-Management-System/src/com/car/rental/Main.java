package com.car.rental;

public class Main {
    public static void main(String[] args) {
        CarRentalSystem rentalSystem = new CarRentalSystem();

        Car car1 = new Car("Prathap_001", "Toyota", "Camry", 60.0); 
        Car car2 = new Car("Prathap_002", "Honda", "Accord", 70.0);
        Car car3 = new Car("Prathap_003", "Ford", "F-150", 150.0);
        Car car4 = new Car("Prathap_004", "Chevrolet", "Malibu", 200.0); 
        Car car5 = new Car("Prathap_005", "Volkswagen", "Golf", 180.0);
        Car car6 = new Car("Prathap_006", "Nissan", "Altima", 90.0);
        Car car7 = new Car("Prathap_007", "BMW","X5", 350.0);
        Car car8 = new Car("Prathap_008", "Mercedes-Benz","GLC", 500.0); 
        Car car9 = new Car("Prathap_009", "Audi", "A4" , 450.0);
        Car car10 = new Car("Prathap_010", "Tesla", "Model S", 2000.0);
        rentalSystem.addCar(car1);
        rentalSystem.addCar(car2);
        rentalSystem.addCar(car3);
        rentalSystem.addCar(car4);
        rentalSystem.addCar(car5);
        rentalSystem.addCar(car6);
        rentalSystem.addCar(car7);
        rentalSystem.addCar(car8);
        rentalSystem.addCar(car9);
        rentalSystem.addCar(car10);
        rentalSystem.menu();
    

    }
}
